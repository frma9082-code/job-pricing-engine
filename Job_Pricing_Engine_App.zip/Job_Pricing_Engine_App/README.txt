JOB PRICING ENGINE (Remodel Contractor Estimator)
=================================================

HOW TO OPEN (NO INSTALL):
1) Unzip this folder.
2) Open index.html in Chrome, Edge, or Safari.
3) Click "Load Example" to see a complete filled-in job.
4) Change numbers and click "Calculate".

WHAT IT DOES:
- Computes burdened labor cost
- Adds overhead allocation
- Calculates break-even price
- Calculates REQUIRED BID price to hit your target profit percent + contingency
- If you enter a "Current Bid", it warns if you're underbidding and by how much
- Save projects in your browser (local only)
- Export saved projects to CSV

NOTES:
- This is a local app: data stays on your device.
- Saved projects are stored in your browser's local storage.
- To run on a phone, you can host it free (GitHub Pages) later.
